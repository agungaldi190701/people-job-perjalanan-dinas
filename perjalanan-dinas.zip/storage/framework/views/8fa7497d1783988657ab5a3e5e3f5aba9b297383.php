
<?php
    $title = 'Daftar-kegiatan';
?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Daftar Kegiatan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">List data seluruh kegiatan</li>
    </ol>


    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->jabatan == 'ketua'): ?>
            <a href="/tambah-kegiatan" class="btn btn-primary">
                Tambah
                <i class="fas fa-plus"></i></a>
        <?php endif; ?>
    <?php endif; ?>
    <div class="card mb-4 mt-2">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Seluruh kegiatan
        </div>
        <div class="card-body">

            <table class="table table-striped" id="example">
                <thead>
                    <tr>
                        <th>No</th>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->jabatan == 'ketua'): ?>
                                <th>Opsi</th>
                            <?php endif; ?>
                        <?php endif; ?>

                        <th>Nama Ketua</th>
                        <th>Nomor Hp Ketua</th>
                        <th>Total Orang</th>
                        <th>Jenis Kegiatan</th>
                        <th>Tanggal Kegiatan</th>
                        <th>Jam Kegiatan</th>
                        <th>Status</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($loop->iteration); ?>

                            </td>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->jabatan == 'ketua'): ?>
                                    <td>
                                        <a href="/edit-kegiatan/<?php echo e($r->id); ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <form action="/hapus-kegiatan/<?php echo e($r->id); ?>" method="post" class="d-inline"
                                            onsubmit="return confirm('Apakah Anda Yakin Mengahus Data Ini ?')">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>

                                            <input type="hidden" name="id" value="<?php echo e($r->id); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm"> <i
                                                    class="fas fa-trash"></i></button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            <?php endif; ?>


                            <td><?php echo e($r->nama_ketua); ?></td>
                            <td><?php echo e($r->nohp_ketua); ?></td>
                            <td><?php echo e($r->total_orang); ?></td>
                            <td><?php echo e($r->jenis_kegiatan); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($r->tanggal)->isoFormat('D MMMM Y')); ?></td>
                            <td><?php echo e($r->jam); ?></td>
                            <td>
                                <span
                                    class="badge rounded-pill <?php echo e($r->status === 'Akan Datang' ? 'bg-success' : 'bg-danger'); ?> "><?php echo e($r->status); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            toastr.success(`<?php echo e(session('success')); ?>`);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/content/kegiatan/kegiatan.blade.php ENDPATH**/ ?>