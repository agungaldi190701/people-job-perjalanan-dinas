

<?php
    
    $total_kegiatan = App\Models\kegiatanModel::count();
    $kegiatan = DB::table('kegiatan')->get();
?>
<?php
    $title = 'list-kegiatan';
?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Daftar Kegiatan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">List data seluruh kegiatan</li>
    </ol>

    <div class="row">

        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-header text-center">
                    Total Kegiatan
                </div>
                <div class="card-body text-center">
                    <h3><?php echo e($total_kegiatan); ?></h3>
                </div>

            </div>
        </div>

    </div>
    <div class="row">
        <div class="col">

            <div class="card mb-4 mt-2">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Data Seluruh kegiatan
                </div>
                <div class="card-body">

                    <table class="table table-striped" id="example">
                        <thead>
                            <tr>
                                <th>No</th>

                                <th>Nama Ketua</th>
                                <th>Nomor Hp Ketua</th>
                                <th>Total Orang</th>
                                <th>Jenis Kegiatan</th>
                                <th>Tanggal Kegiatan</th>
                                <th>Jam Kegiatan</th>
                                <th>Status</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($loop->iteration); ?>

                                    </td>

                                    <td><?php echo e($r->nama_ketua); ?></td>
                                    <td><?php echo e($r->nohp_ketua); ?></td>
                                    <td><?php echo e($r->total_orang); ?></td>
                                    <td><?php echo e($r->jenis_kegiatan); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($r->tanggal)->isoFormat('D MMMM Y')); ?></td>
                                    <td><?php echo e($r->jam); ?></td>
                                    <td>
                                        <span
                                            class="badge rounded-pill <?php echo e($r->status === 'Akan Datang' ? 'bg-success' : 'bg-danger'); ?> "><?php echo e($r->status); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            toastr.success(`<?php echo e(session('success')); ?>`);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/content/kegiatan/indexKegiatan.blade.php ENDPATH**/ ?>