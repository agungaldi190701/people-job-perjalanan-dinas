<?php if(auth()->guard()->check()): ?>
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">Menu</div>
                    
                    <a class="nav-link <?php echo e(Request::is('honorer') ? 'active' : ''); ?>" href="/honorer">
                        <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                        Honorer
                    </a>
                    <a class="nav-link <?php echo e(Request::is('pns') ? 'active' : ''); ?>" href="/pns">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        PNS
                    </a>
                    <a class="nav-link <?php echo e(Request::is('daftar-kegiatan') ? 'active' : ''); ?>" href="/daftar-kegiatan">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Kegiatan
                    </a>

                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->jabatan == 'ketua'): ?>
                            <div class="sb-sidenav-menu-heading">Data</div>
                            <a class="nav-link <?php echo e(Request::is('kegiatan') ? 'active' : ''); ?>" href="/kegiatan">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Daftar Kegiatan
                            </a>
                        <?php endif; ?>
                        <?php if(Auth::user()->jabatan == 'admin'): ?>
                            <div class="sb-sidenav-menu-heading">Data</div>
                            <a class="nav-link <?php echo e(Request::is('anggota') ? 'active' : ''); ?>" href="/anggota">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Daftar Anggota
                            </a>
                            <a class="nav-link <?php echo e(Request::is('kegiatan') ? 'active' : ''); ?>" href="/kegiatan">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Daftar Kegiatan
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Logged in as:</div>
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(Auth::user()->jabatan); ?>

                <?php else: ?>
                    Guest
                <?php endif; ?>
            </div>
        </nav>
    </div>
<?php endif; ?>
<?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/layout/support/sidebar.blade.php ENDPATH**/ ?>