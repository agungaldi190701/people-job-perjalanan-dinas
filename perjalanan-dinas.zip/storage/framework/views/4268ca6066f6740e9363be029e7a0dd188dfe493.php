
<?php
    $previous = 'javascript:history.go(-1)';
    if (isset($_SERVER['HTTP_REFERER'])) {
        $previous = $_SERVER['HTTP_REFERER'];
    }
    $title = 'Edit Profile';
?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">
        Edit Profile</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Lengkapi semua data anda dibawah ini</li>
    </ol>
    <div class="container rounded bg-white mt-5 mb-5">
        
        <form action="/update-profile" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-3 border-right">
                        <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img
                                class="rounded-circle mt-5" width="100%" src="<?php echo e(asset('img/' . $item->foto)); ?>"><span
                                class="font-weight-bold"><?php echo e($item->nama); ?></span><span
                                class="text-black-50"><?php echo e($item->username); ?></span><span>
                            </span>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Perbarui Foto</label>
                            <input type="file" class="form-control" placeholder="foto" name="foto"
                                value="<?php echo e($item->foto); ?>">
                            <input type="hidden" name="foto_lama" value="<?php echo e($item->foto); ?>">
                        </div>
                    </div>
                    <div class="col-md-5 border-right">
                        <div class="p-3 py-5">

                            <div class="row mt-2">
                                <div class="col-md-12">
                                    <label class="labels">Nama Lengkap</label>
                                    <input type="text" class="form-control" placeholder="Your Name" name="nama"
                                        value="<?php echo e($item->nama); ?>">
                                    <input type="hidden" class="form-control" name="id" value="<?php echo e($item->id); ?>">
                                </div>

                            </div>

                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <label class="labels">NIP</label>
                                    <input type="text" class="form-control" placeholder="NIP" name="nip"
                                        value="<?php echo e($item->nip); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="labels">Jabatan</label>
                                    <input type="text" class="form-control" value="<?php echo e($item->jabatan); ?>   "
                                        placeholder="jabatan" name="jabatan" readonly>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <label class="labels">Nomor Hp</label>
                                    <input type="text" class="form-control" placeholder="nohp" name="nohp"
                                        value="<?php echo e($item->nohp); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="labels">Jenis Kelamin</label>
                                    <select name="jenis_kelamin" id="" class="form-select">
                                        <option value="Laki-laki" <?php if($item->jenis_kelamin == 'Laki-laki'): ?> selected <?php endif; ?>>
                                            Laki-laki</option>
                                        <option value="Perempuan" <?php if($item->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>
                                            Perempuan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-4">
                                    <label class="labels">Username</label>
                                    <input type="text" class="form-control" value="<?php echo e($item->username); ?>"
                                        placeholder="Username" name="username">
                                </div>
                                <div class="col-md-6">
                                    <label class="labels">Ubah Password</label>
                                    <input type="text" class="form-control" placeholder="password" name="password">

                                </div>
                                <div class="col-md-2 mt-4">
                                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="mt-5 text-center">

                                <a href="<?php echo e($previous); ?>" class="btn btn-secondary"> Kembali</a>
                                <button class="btn
                                    btn-primary " type="submit">Simpan
                                    Perubahan
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Password Anda</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="text" class="form-control" value="<?php echo e($item->password); ?>"
                                        placeholder="password_lama" name="password_lama" readonly>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>

    </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/content/anggota/editProfile.blade.php ENDPATH**/ ?>