
<?php
    $title = 'Edit-Kegiatan';
?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Edit Kegiatan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Lengkapi semua data Kegiatan dibawah ini</li>
    </ol>

    <div class="card">
        <div class="card-body">
            <form action="/update-kegiatan" method="POST">

                
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                

                <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="ketua" name="ketua"
                                    value="<?php echo e($r->nama_ketua); ?>" autofocus>
                                <label for="ketua">Nama Ketua Rombongan</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="number" class="form-control" id="nohp_ketua" name="nohp_ketua"
                                    value="<?php echo e($r->nohp_ketua); ?>">
                                <label for="nohp_ketua">Nomor Hp Ketua Rombongan</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <div class="form-floating">
                                    <input type="number" class="form-control" id="total_orang" name="total_orang"
                                        value="<?php echo e($r->total_orang); ?>">
                                    <label for="total_orang">Total Orang</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" id="option_kegiatan">
                            <div class="form-floating">
                                <select name="jenis_kegiatan2" id="jenis_kegiatan" class="form-select">

                                    <option value="<?php echo e($r->jenis_kegiatan); ?>"><?php echo e($r->jenis_kegiatan); ?></option>
                                    <option value="Perpustakaan Jalan">Perpustakaan Jalan</option>
                                    <option value="Undangan">Undangan</option>
                                    <option value="Upacara">Upacara</option>
                                    <option>Lainya</option>

                                </select>
                                <label for="jenis_kegiatan">Piih jenisKegiatan ----</label>

                            </div>
                        </div>
                        <div class="col-md-6" id="lainya">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="jenis_kegiatan" name="jenis_kegiatan">
                                <label for="jenis_kegiatan">jenis_kegitan</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="date" class="form-control" id="tanggal" name="tanggal"
                                    value="<?php echo e($r->tanggal); ?>">
                                <label for="tanggal">Tanggal Kegiatan</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="time" class="form-control" id="jam" name="jam"
                                    value="<?php echo e($r->jam); ?>">
                                <label for="jam">Jam Kegiatan</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-floating">
                                <select name="status" id="status" class="form-select">

                                    <option value="<?php echo e($r->status); ?>"><?php echo e($r->status); ?></option>
                                    <option value="Akan Datang">Akan Datang</option>
                                    <option value="Sudah Selesai">Sudah Selesai</option>

                                </select>
                                <label for="status">Piih status ----</label>
                            </div>
                        </div>

                        <input type="hidden" class="form-control" id="id" name="id"
                            value="<?php echo e($r->id); ?>">

                        <div class="col-6">
                            <a href="/kegiatan"class="btn btn-secondary w-100 py-3">Kembali</a>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-success w-100 py-3" type="submit">Update Data</button>
                        </div>


                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if(count($errors) > 0): ?>
        <script>
            toastr.error(`<?php echo e($errors->first()); ?>`);
        </script>
    <?php endif; ?>
    <script>
        $('#lainya').hide();
        $('#jenis_kegiatan').change(function() {
            if ($('select option:selected').text() == "Lainya") {
                $('#option_kegiatan').hide();
                $('#lainya').show();
            } else {}
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/content/kegiatan/editKegiatan.blade.php ENDPATH**/ ?>