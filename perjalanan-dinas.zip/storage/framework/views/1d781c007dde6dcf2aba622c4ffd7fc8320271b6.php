

<?php
    $total_anggota = DB::table('users')
        ->where('jenis_anggota', 'pns')
        ->count();
    $anggota = DB::table('users')
        ->where('jenis_anggota', 'pns')
        ->get();
    $title = 'list-pns';
?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Data Anggota PNS</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">List Semua Data Anggota</li>
    </ol>
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4">
                <div class="card-header text-center">
                    Total Anggota
                </div>
                <div class="card-body text-center">
                    <h3><?php echo e($total_anggota); ?></h3>
                </div>

            </div>
        </div>


    </div>
    <div class="row">
        <div class="card mb-4 mt-2">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Data Seluruh Anggota
            </div>
            <div class="card-body">

                <table class="table table-striped" id="example">
                    <thead>
                        <tr>

                            <th>No</th>
                            <th>Foto</th>
                            <th>NIP</th>
                            <th>Nama Anggota</th>
                            <th>Jenis Kelamin</th>
                            <th>Jabatan</th>
                            <th>No Hp</th>



                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <img src="<?php echo e(asset('img/' . $r->foto)); ?>" class="img-rounded" alt="Gambar malas ngoding"
                                        width="50" height="50">


                                </td>
                                <td><?php echo e($r->nip); ?></td>
                                <td><?php echo e($r->nama); ?></td>
                                <td><?php echo e($r->jenis_kelamin); ?></td>
                                <td><?php echo e($r->jabatan); ?></td>
                                <td><?php echo e($r->nohp); ?></td>
                            </tr>
                            <!-- Modal -->
                            <div class="modal fade" id="tambah-anggota<?php echo e($r->id); ?>" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Info Anggota</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <img src="<?php echo e(asset('img/' . $r->foto)); ?>" alt="" width="100%">
                                                </div>
                                                <div class="col-md-4">
                                                    <p>NIP</p>
                                                    <p>Nama</p>
                                                    <p>Jenis Kelamin</p>
                                                    <p>Jabatan</p>
                                                    <p>No Hp</p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p>: <?php echo e($r->nip); ?></p>
                                                    <p>: <?php echo e($r->nama); ?></p>
                                                    <p>: <?php echo e($r->jenis_kelamin); ?></p>
                                                    <p>: <?php echo e($r->jabatan); ?></p>
                                                    <p>: <?php echo e($r->nohp); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Close</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            toastr.success(`<?php echo e(session('success')); ?>`);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/content/anggota/pns.blade.php ENDPATH**/ ?>