
<?php
    $title = 'list-anggota';
?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Daftar Anggota</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">List data seluruh anggota</li>
    </ol>

    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->jabatan == 'admin'): ?>
            <a href="/tambah-anggota" class="btn btn-primary">
                Tambah
                <i class="fas fa-plus"></i></a>
        <?php endif; ?>
    <?php endif; ?>

    <div class="card mb-4 mt-2">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Seluruh Anggota
        </div>
        <div class="card-body">

            <table class="table table-striped" id="example">
                <thead>
                    <tr>
                        <th>No</th>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->jabatan == 'admin'): ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                        <?php endif; ?>
                        <th>NIP</th>
                        <th>Nama Anggota</th>
                        <th>Jenis Kelamin</th>
                        <th>Jabatan</th>
                        <th>No Hp</th>



                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->jabatan == 'admin'): ?>
                                    <td>
                                        <a href="/edit-anggota/<?php echo e($r->id); ?>" class="btn btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <form action="/hapus-anggota/<?php echo e($r->id); ?>" method="post" class="d-inline"
                                            onsubmit="return confirm('Apakah Anda Yakin Mengahus Data Ini ?')">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>

                                            <input type="hidden" name="id" value="<?php echo e($r->id); ?>">
                                            <button type="submit" class="btn btn-danger "> <i
                                                    class="fas fa-trash"></i></button>
                                        </form>

                                        <button type="button" class="btn btn-info" data-bs-toggle="modal"
                                            data-bs-target="#tambah-anggota<?php echo e($r->id); ?>">
                                            <i class="fas fa-info-circle"></i>
                                        </button>
                                    </td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <td><?php echo e($r->nip); ?></td>
                            <td><?php echo e($r->nama); ?></td>
                            <td><?php echo e($r->jenis_kelamin); ?></td>
                            <td><?php echo e($r->jabatan); ?></td>
                            <td><?php echo e($r->nohp); ?></td>
                        </tr>
                        <!-- Modal -->
                        <div class="modal fade" id="tambah-anggota<?php echo e($r->id); ?>" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Info Anggota</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <img src="<?php echo e(asset('img/' . $r->foto)); ?>" alt="" width="100%">
                                            </div>
                                            <div class="col-md-4">
                                                <p>NIP</p>
                                                <p>Nama</p>
                                                <p>Jenis Kelamin</p>
                                                <p>Jabatan</p>
                                                <p>No Hp</p>
                                            </div>
                                            <div class="col-md-4">
                                                <p>: <?php echo e($r->nip); ?></p>
                                                <p>: <?php echo e($r->nama); ?></p>
                                                <p>: <?php echo e($r->jenis_kelamin); ?></p>
                                                <p>: <?php echo e($r->jabatan); ?></p>
                                                <p>: <?php echo e($r->nohp); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            toastr.success(`<?php echo e(session('success')); ?>`);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\JOKI\perjalanan-dinas\resources\views/content/anggota/anggota.blade.php ENDPATH**/ ?>